<h3>Halo, {{$details['asal_surat']}} !</h3>
 
<p>Rekomendasi Pendirian Rumah Ibadah anda telah berhasil</a></p>
<p>Berikut ini adalah kode pengajuan anda</p>
<h2>{{$details['id']}}</h2>