<h3>Halo, Terdapat pengajuan baru dari {{$details['email']}} !</h3>
 
<p>Nama Pemohon :  {{$details['nama_pemohon']}} !</p>
<p>Nama Masjid : {{$details['nama_masjid']}}</p>
<p>Jenis Layanan : Rekomendasi Bantuan Masjid </p>
<p> Berikut adalah kode tracking pengajuan anda</p>
<h2>{{$details['id']}}</h2>