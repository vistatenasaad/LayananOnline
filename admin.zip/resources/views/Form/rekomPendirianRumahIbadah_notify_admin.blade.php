<h3>Halo, Terdapat pengajuan baru dari {{$details['email']}} !</h3>
 
<p>Nama : {{$details['asal_surat']}} </a></p>
<p>Jenis Layanan : Rekomendasi Pendirian Rumah Ibadah </p>
<p> Berikut adalah kode tracking pengajuan anda</p>
<h2>{{$details['id']}}</h2>