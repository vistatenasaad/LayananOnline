<h3>Halo, Terdapat pengajuan baru dari {{$details['email']}} !</h3>
 
<p>Nama : {{$details['nama_siswa']}} </a></p>
<p>Jenis Layanan : Pengajuan Pengantar Rekomendasi Studi Luar Negeri di Kota Batu </p>
<p> Berikut adalah kode tracking pengajuan anda</p>
<h2>{{$details['id']}}</h2>