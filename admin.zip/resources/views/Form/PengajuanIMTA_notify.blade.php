<h3>Halo, {{$details['nama_lembaga']}} !</h3>
 
<p>Pengajuan Dana Kompensasi Penggunaan Orang Asing ada telah berhasil</a></p>
<p>Berikut ini adalah kode pengajuan anda</p>
<h2>{{$details['id']}}</h2>