<h3>Halo, {{$details['nama_pemohon']}} !</h3>
<p>Nama Masjid : {{$details['nama_masjid']}}</p>

<p>Rekomendasi Bantuan Masjid anda telah berhasil</a></p>
<p>Berikut ini adalah kode pengajuan anda</p>
<h2>{{$details['id']}}</h2>