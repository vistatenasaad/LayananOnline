<h3>Halo, {{$details['nama_siswa']}} !</h3>
<p>Asal Madrasah : {{$details['asal_madrasah']}}</p>
<p>Madrasah Dituju : {{$details['madrasah_dituju']}}</p>

<p>Pengajuan Rekomendasi Pindah Madrasah/ Sekolah anda telah berhasil</a></p>
<p>Berikut ini adalah kode pengajuan anda</p>
<h2>{{$details['id']}}</h2>