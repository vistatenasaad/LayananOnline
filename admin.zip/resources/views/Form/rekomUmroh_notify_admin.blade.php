<h3>Halo, Terdapat pengajuan baru dari {{$details['email']}} !</h3>
 
<p>Nama : {{$details['nama']}} </a></p>
<p>Jenis Layanan : Pengajuan Rekomendasi Penerbitan Paspor Ibadah Umroh pada Kankemenag Kota Batu </p>
<p> Berikut adalah kode tracking pengajuan anda</p>
<h2>{{$details['id']}}</h2>