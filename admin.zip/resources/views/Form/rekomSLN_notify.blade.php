<h3>Halo, {{$details['nama_siswa']}} !</h3>
 
<p>Pengajuan Pengantar Rekomendasi Studi Luar Negeri di Kota Batu anda telah berhasil</a></p>
<p>Berikut ini adalah kode pengajuan anda</p>
<h2>{{$details['id']}}</h2>