<h3>Halo, Terdapat pengajuan baru dari {{$details['email']}} !</h3>
 
<p>Nama Siswa : {{$details['nama_siswa']}} !</p>
<p>Asal Madrasah : {{$details['asal_madrasah']}}</p>
<p>Madrasah Dituju : {{$details['madrasah_dituju']}}</p>
<p>Jenis Layanan : Pengajuan Rekomendasi Pindah Madrasah/ Sekolah </p>
<p> Berikut adalah kode tracking pengajuan anda</p>
<h2>{{$details['id']}}</h2>