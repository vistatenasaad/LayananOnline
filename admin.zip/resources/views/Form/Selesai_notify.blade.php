<h3>Halo, {{$details['email']}} !</h3>
 
<p>Pengajuan anda telah </p> <strong>SELESAI</strong>
<p>Berikut ini adalah kode pengajuan anda</p>
<h2>{{$details['id']}}</h2>