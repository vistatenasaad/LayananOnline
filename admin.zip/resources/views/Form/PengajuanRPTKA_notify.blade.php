<h3>Halo, {{$details['nama_lembaga']}} !</h3>
 
<p>Pengajuan Rencana Penggunaan Tenaga Kerja Asing ada telah berhasil</a></p>
<p>Berikut ini adalah kode pengajuan anda</p>
<h2>{{$details['id']}}</h2>