<h3>Halo, Terdapat pengajuan baru dari {{$details['email']}} !</h3>
 
<p>Nama : {{$details['nama_lembaga']}} </a></p>
<p>Jenis Layanan : Naturalisasi </p>
<p> Berikut adalah kode tracking pengajuan anda</p>
<h2>{{$details['id']}}</h2>