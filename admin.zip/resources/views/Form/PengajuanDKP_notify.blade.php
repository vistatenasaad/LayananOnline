<h3>Halo, {{$details['nama']}} !</h3>
 
<p>Pengajuan Dana Kompensasi Penggunaan Orang Asing anda telah berhasil</a></p>
<p>Berikut ini adalah kode pengajuan anda</p>
<h2>{{$details['id']}}</h2>