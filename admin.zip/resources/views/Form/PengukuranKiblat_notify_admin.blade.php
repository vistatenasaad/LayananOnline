<h3>Halo, Terdapat pengajuan baru dari {{$details['email']}} !</h3>
 
<p>Nama : {{$details['nama']}} !</p>
<p>Nama Masjid : {{$details['nama_masjid']}}</p>
<p>Jenis Layanan : Pengajuan Pengukuran Kiblat </p>
<p> Berikut adalah kode tracking pengajuan anda</p>
<h2>{{$details['id']}}</h2>