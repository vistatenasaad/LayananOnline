<h3>Halo, {{$details['nama']}} !</h3>
<p>Nama Masjid : {{$details['nama_masjid']}}</p>
 
<p>Pengajuan Pengukuran Kiblat anda telah berhasil</a></p>
<p>Berikut ini adalah kode pengajuan anda</p>
<h2>{{$details['id']}}</h2>