<h3>Halo, {{$details['email']}} !</h3>
 
<p>Pengajuan anda </p> <strong>DITOLAK</strong>
<p>Berikut ini adalah kode pengajuan anda</p>
<h2>{{$details['id']}}</h2>
<p>Alasan</p>
<h3>{{$details['pesan']}}</h3>