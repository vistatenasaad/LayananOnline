<h3>Halo, {{$details['nama']}} !</h3>
<p>Nama Masjid : {{$details['nama_masjid']}}</p>
 
<p>Pengajuan Pengukuran Kiblat ada telah berhasil</a></p>
<p>Berikut ini adalah kode pengajuan anda</p>
<h2>1234567abc</h2>