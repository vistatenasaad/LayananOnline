<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class permohonan_pajak extends Model
{
    //
}
