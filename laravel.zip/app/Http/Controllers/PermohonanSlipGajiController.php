<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PermohonanSlipGajiController extends Controller
{
    public function PermohonanSlipGaji(){
		return view('Form.PermohonanSlipGaji');
	}
}
