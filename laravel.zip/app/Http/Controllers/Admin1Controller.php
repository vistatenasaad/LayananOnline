<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Admin1Controller extends Controller
{
    //
}
